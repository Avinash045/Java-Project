package all_ops;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import admin_ops.Admin_ops;
import db_config.Databaseconfig;
import ticketBook.TicketBoot;
import user_Details.RegisterUser;

public class Operations {
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		boolean b=true;
		try {
			Connection con = DriverManager.getConnection(Databaseconfig.URL,Databaseconfig.USERNAME,Databaseconfig.PASSWORD);
			PreparedStatement ad_log=con.prepareStatement("select * from admin where user_id=? and password=?");
			PreparedStatement user_log=con.prepareStatement("select * from user where u_id=? and pass=?");
//			PreparedStatement fligt=con.prepareStatement("select * from flight_info");
			while(b) {
				System.out.println("**Welcome to Vikas Airline Management**");
				System.out.println();
				System.out.println("***    Choice    ***");
				System.out.println("\t1.Register\n\t2.Login\n\t3.Exit");
				System.out.println();
				System.out.println("Enter your choice:---> ");
				System.out.println();
				int choice =sc.nextInt();
				switch(choice){
				 case 1:
					 	System.out.println("*******Welcome To User Registration*******");
					 	RegisterUser user =new RegisterUser();
					 	int k=user.registerUser();
					 	if(k>0) {
					 		System.out.println("User Registered Successfully!!!!");
					 	}
					 	else {
					 		System.out.println("Something went wrong!!! please try again");
					 	}
					 	break;
				 case 2:
					   System.out.println("Welcome To Login Section:");
					   boolean flag=true;
					   while(flag) {
						   System.out.println("\t1.Admin Login\n\t2.User login");
						   System.out.println();
						   System.out.println("Enter your choice:---->");
						   int c= sc.nextInt();
						   switch(c) {
						   	case 1:
						   		System.out.println("Login as Admin: ");
						   		   System.out.print("Enter Admin Name: ");
						   		   sc.nextLine();
						   		   String id=sc.nextLine();
						   		   ad_log.setString(1, id);
						   		   System.out.print("Enter Admin Password: ");
						   		   String pass=sc.nextLine();
						   		   ad_log.setString(2, pass);
						   		   ResultSet rs=ad_log.executeQuery();
						   		   if(rs.next()) {
						   			   System.out.println("Admin Name is: "+rs.getString(3));
						   			   //add options for add flight ,delete flight,delete user
						   			   boolean v=true;
						   			   while(v) {
						   				   System.out.println();
						   				   System.out.println("Welcome To Admin Section!!");
						   				   System.out.println("Operation to performs!!");
						   				   System.out.println("\t1.Add Flight\n\t2.Delete Flight\n\t3.View Users\n\t4.Delete User\n\t5.View All Flights\n\t6.Exit");
						   				   System.out.println("Enter Your Chice: ");
						   				  int ch= sc.nextInt();
						   				  switch(ch) {
						   				      case 1:
						   				    	   int result =new Admin_ops().bookflight();
									   			   if (result>0) {
									   				   System.out.println("Filght added Successfully!!!");
									   			   }
									   			   else {
									   				   System.out.println("Something went wrong please try again!!");
									   			   }
						   				  		    break;
						   			   		  case 2:
						   			   			    int delete_flight=new Admin_ops().deleteFlight();
						   			   			    if(delete_flight>0) {
						   			   			    	System.out.println("Flight Deleted Successfully!!!");
						   			   			    }
						   			   			    else {
						   			   			    	System.out.println("Flight not deleted !!!");
						   			   			    }
		   				  				            break;
						   			   		  case 3:
						   			   			  Scanner scanner = new Scanner(System.in);
						   			   			  System.out.println("Select Your Choice----> ");
						   			   			  System.out.println("1) View Users by Id ");
						   			   			  System.out.println("2) View all Users  ");
						   			   			  int choice1 = scanner.nextInt();
						   			   			  
						   			   		 try {
						   			            // Assuming you have the JDBC driver loaded and a connection established
						   			   			 Connection con1 =DriverManager.getConnection(Databaseconfig.URL,Databaseconfig.USERNAME,Databaseconfig.PASSWORD);
						   			   			 Scanner sc1=new Scanner(System.in);
						   			            switch (choice1) {
						   			                case 1:
						   			                    System.out.print("Enter User Id: ");
						   			                    int userId = sc1.nextInt();
						   			                    PreparedStatement pstmtById = con1.prepareStatement("select * from user where u_id = ?");
						   			                    pstmtById.setInt(1, userId);
						   			                    ResultSet userById = pstmtById.executeQuery();
						   			                    if (userById.next()) {
						   			                        System.out.println("Displaying User Details!!!!");
						   			                        System.out.println("User Id: " + userById.getInt(1) + "\t" + "Name: " + userById.getString(3) + "\t" + "Gender: " + userById.getString(4) + "\t" + "Age: " + userById.getString(5));
						   			                    } else {
						   			                        System.out.println("User not found.");
						   			                    }
						   			                    break;

						   			                case 2:
						   			                    PreparedStatement pstmtAll = con1.prepareStatement("select * from user");
						   			                    ResultSet users = pstmtAll.executeQuery();
						   			                    while (users.next()) {
						   			                        System.out.println();
						   			                        System.out.println("Displaying User Details!!!!");
						   			                        System.out.println("User Id: " + users.getInt(1) + "\t" + "Name: " + users.getString(3) + "\t" + "Gender: " + users.getString(4) + "\t" + "Age: " + users.getString(5));
						   			                    }
						   			                    break;

						   			                default:
						   			                    System.out.println("Invalid choice. Please select 1 or 2.");
						   			            }

						   			            con1.close();
						   			        } catch (Exception e) {
						   			            e.printStackTrace();
						   			        }
						   			   break;
						   			   		  case 4:
						   			   			    int userDelete=new Admin_ops().deleteUser();
						   			   			    if(userDelete>0) {
						   			   			    	System.out.println("User Deleted Successfully!!!");
						   			   			    }
						   			   			    else {
						   			   			    	System.out.println("Invalid Id!!!");
						   			   			    }
						   			   			    break;
						   			   		  case 5:
						   			   			 PreparedStatement pstmtAll = con.prepareStatement("select * from flight_info");
				   			                    ResultSet flight = pstmtAll.executeQuery();
				   			                    while (flight.next()) {
				   			                        System.out.println();
				   			                        System.out.println("Displaying Flight Details!!!!");
				   			                        System.out.println("Flight Id: " + flight.getInt(1) + "\t" + "Flight_Name: " + flight.getString(2) + "\t" + "Departure Point: " + flight.getString(3) + "\t" + "Arrival point: " + flight.getString(4) + "\t" + "Flight_Price: " + flight.getInt(5));
				   			                    }
				   			                    break;
						   			   		  case 6:v=false;
						   			   		  		break;
						   				   
						   				   
						   				  	}//switch
						   			   }//while
						   		   }//if
						   		   else {
						   			   System.out.println("Invalid credentials");
						   		   }
						   		   break;
						   	case 2:
						   			System.out.println();
						   		   System.out.println("Login as User: ");
						   		   System.out.println();
						   		   System.out.print("Enter your Id: ");
						   		   int u_id=sc.nextInt();
						   		   user_log.setInt(1, u_id);
						   		   System.out.print("Enter your Password: ");
						   		   sc.nextLine();
						   		   String pass1=sc.nextLine();
						   		   user_log.setString(2, pass1);
						   		   ResultSet rs1=user_log.executeQuery();
						   		   if(rs1.next()) {
						   			   System.out.println("Welcome user : "+rs1.getString(3));
						   			   boolean user_ops=true;
						   			   while(user_ops) {
						   				   System.out.println("Welcome to User Section what do you want to perform!!!!");
						   				   System.out.println("\t1.Update Profile\n\t2.Book Ticket\n\t3.Exit");
						   				   System.out.println("enter your choice!!!");
						   				 
						   				   int ch=sc.nextInt();
						   				   
						   				   switch(ch) {
						   				   	case 1:
						   				   		int update=new RegisterUser().Update();
						   				   		if(update>0) {
						   				   			System.out.println("Update Successfully!!");
						   				   		}
						   				   		else {
						   				   			System.out.println("Invalid Details!!");
						   				   		}
						   				   		   break;
						   				   	case 2:
						   				   	Scanner sc1 = new Scanner(System.in);
						   			        Connection conn = null;

						   			        try {
						   			            // Initialize your database connection
						   			            conn = DriverManager.getConnection(Databaseconfig.URL, Databaseconfig.USERNAME, Databaseconfig.PASSWORD);

						   			            System.out.println("Enter From:");
						   			            String from = sc1.next();
						   			            System.out.println("Enter Destination:");
						   			            String destination = sc1.next();

						   			            // Prepare the query to avoid SQL injection
						   			            String query = "SELECT * FROM flight_info WHERE Destination = ? AND Boarding = ?";
						   			            PreparedStatement pstmt = conn.prepareStatement(query);
						   			            pstmt.setString(1, from);
						   			            pstmt.setString(2, destination);

						   			            ResultSet flights = pstmt.executeQuery();

						   			            boolean flightAvailable = false;
						   			            while (flights.next()) {
						   			                if (!flightAvailable) {
						   			                    System.out.println("Available Flights are...");
						   			                    flightAvailable = true;
						   			                }
						   			                System.out.println("Flight Id: " + flights.getInt(1) + "\t" +
						   			                                   "Flight Name: " + flights.getString(2) + "\t" +
						   			                                   "Flight Destination: " + flights.getString(3) + "\t" +
						   			                                   "Flight Boarding: " + flights.getString(4) + "\t" +
						   			                                   "Flight Ticket Price: " + flights.getString(5));
						   			            }

						   			            if (!flightAvailable) {
						   			                System.out.println("Sorry No Available Flight For this Journey");
						   			            } else {
						   			                int bookTic = new TicketBoot().bookTicket(); // Make sure this method handles booking based on the selected flight
						   			                if (bookTic > 0) {
						   			                    System.out.println("Ticket Booked Successfully!!!");
						   			                } else {
						   			                    System.out.println("Ticket Not Booked!!!");
						   			                }
						   			            }

						   			            // Close the ResultSet and PreparedStatement
						   			            flights.close();
						   			            pstmt.close();
						   			        	} catch (SQLException e) {
						   			            e.printStackTrace();
						   			        	} finally {
						   			            try {
						   			                if (conn != null) conn.close();
						   			            } catch (SQLException e) {
						   			                e.printStackTrace();
						   			            }
						   			        	}
						   			        	case 3:System.out.println("Exiting!!!!!");
									   			b=false;
									   			break;
						   			        }
						   				   break;
						   			    }
						   			  
						   			   }
						   		  else {
						   			   System.out.println("Invalid credentials");
						   		   }
						   		   break;
						   }
						   }
						    
					   }
					   
				}
			
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
	}
	}

