package user_Details;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

import db_config.Databaseconfig;

public class RegisterUser {
	private int k=0;
	public int registerUser() {
		try {
			Connection con =DriverManager.getConnection(Databaseconfig.URL,Databaseconfig.USERNAME,Databaseconfig.PASSWORD);
			Scanner sc=new Scanner(System.in);
			PreparedStatement pstmt = con.prepareStatement("insert into user values(?,?,?,?,?)");
			System.out.print("Enter the user id: ");
			int id=sc.nextInt();
			pstmt.setInt(1, id);
			System.out.print("Enter the pass: ");
			sc.nextLine();
			String pass=sc.nextLine();
			pstmt.setString(2, pass);
			System.out.print("Enter the Name: ");
			String name=sc.nextLine();
			pstmt.setString(3, name);
			System.out.print("Enter the Gender: ");
			String gender=sc.nextLine();
			pstmt.setString(4, gender);
			System.out.print("Enter the Age: ");
			String age=sc.nextLine();
			pstmt.setString(5, age);
			
			k=pstmt.executeUpdate();
			
			
			return k;
		}catch (Exception e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
			return 0;
		}
		
	}
	
	public int Update() {
		int i=0;
		try {
			Connection con =DriverManager.getConnection(Databaseconfig.URL,Databaseconfig.USERNAME,Databaseconfig.PASSWORD);
			Scanner sc=new Scanner(System.in);
			boolean n= true;
			while(n) {
				System.out.println();
				System.out.println("Update the details: ");
				System.out.println("----------------------");
				System.out.println("1.Update User Password: ");
				System.out.println("2.Update User Name: ");
				System.out.println("3.Update User Gender: ");
				System.out.println("4.Update User Age: ");
				System.out.println("5.Exit");
				
				System.out.println("Enter Your Choice:--->" );
				
				int choice=sc.nextInt();
				
				switch(choice) {
				 	case 1:
				 		System.out.println("Update User Password!!");
				 		PreparedStatement u_id=con.prepareStatement("UPDATE user SET pass = ? WHERE u_id = ? ");
				 		System.out.print("Enter the User Id: ");
						int u_id1=sc.nextInt();
						System.out.print("Enter New Password: ");
						sc.nextLine();
						String up=sc.nextLine();
						u_id.setString(1, up);
						u_id.setInt(2, u_id1);
						int u_i= u_id.executeUpdate();
						
						if(u_i>0) {
							System.out.println("User Password Updated! ");
						}else {
							System.out.println("Invalid Passenge ID! ");
						}
						break;
						
				 	case 2:
				 		System.out.println("Update User Name!!");
				 		PreparedStatement u_name=con.prepareStatement("UPDATE user SET u_name = ? WHERE u_id = ? ");
				 		System.out.print("Enter the User Id: ");
						int u_id2=sc.nextInt();
						System.out.print("Enter New Name: ");
						sc.nextLine();
						String up1=sc.nextLine();
						u_name.setString(1, up1);
						u_name.setInt(2, u_id2);
						int u_i1= u_name.executeUpdate();
						
						if(u_i1>0) {
							System.out.println("User Name Updated! ");
						}else {
							System.out.println("Invalid Passenge ID! ");
						}
						break;
						
				 	case 3:
				 		System.out.println("Update User Gender!!");
				 		PreparedStatement u_gen=con.prepareStatement("UPDATE user SET Gender = ? WHERE u_id = ? ");
				 		System.out.print("Enter the User Id: ");
						int u_id3=sc.nextInt();
						System.out.print("Enter New Gender: ");
						sc.nextLine();
						String up2=sc.nextLine();
						u_gen.setString(1, up2);
						u_gen.setInt(2, u_id3);
						int u_i2= u_gen.executeUpdate();
						
						if(u_i2>0) {
							System.out.println("User Gender Updated! ");
						}else {
							System.out.println("Invalid Passenge ID! ");
						}
						break;
						
				 	case 4:
				 		System.out.println("Update User Age!!");
				 		PreparedStatement u_age=con.prepareStatement("UPDATE user SET age = ? WHERE u_id = ? ");
				 		System.out.print("Enter the User Id: ");
						int u_id4=sc.nextInt();
						System.out.print("Enter New Age: ");
						sc.nextLine();
						String up3=sc.nextLine();
						u_age.setString(1, up3);
						u_age.setInt(2, u_id4);
						int u_i3= u_age.executeUpdate();
						
						if(u_i3>0) {
							System.out.println("User Age Updated! ");
						}else {
							System.out.println("Invalid Passenge ID! ");
						}
						break;
						
				 	case 5:System.out.println("Exiting....");
			   		   n=false;
				}
			}
			
			return i;
	}catch (Exception e) {
		System.out.println(e.getMessage());
	}
		return i;
	
	
	}	
}


