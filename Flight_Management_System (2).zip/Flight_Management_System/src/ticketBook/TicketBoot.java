package ticketBook;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Random;
import java.util.Scanner;

import db_config.Databaseconfig;

public class TicketBoot {
	
	private int k=0;
	public int bookTicket() {
		Random r = new Random();
		try {
			Connection con =DriverManager.getConnection(Databaseconfig.URL,Databaseconfig.USERNAME,Databaseconfig.PASSWORD);
			Scanner sc=new Scanner(System.in);
			PreparedStatement pstmt = con.prepareStatement("insert into t_details values(?,?,?,?,?,?)");
			System.out.println("Enter Register User Id: ");
			int id=sc.nextInt();
			pstmt.setInt(1, id);
			
			System.out.print("Enter the Ticket Id: ");
			sc.nextLine();
			//String t_id=sc.nextLine();
			int t_id= r.nextInt(111,999);
			System.out.println(t_id);
			pstmt.setInt(2, t_id);
			
			System.out.println("Enter the Ticket Departure : ");
			String desti= sc.nextLine();
			pstmt.setString(3, desti);
			
			System.out.println("Enter the Ticket Arrival: ");
			String board= sc.nextLine();
			pstmt.setString(4, board);
			
			
			System.out.println("Enter the Flight Id: ");
			int flight_id= sc.nextInt();
			pstmt.setInt(5, flight_id);
			
			System.out.println("Enter the Date Of Journey: ");
			sc.nextLine();
			String flight_date= sc.nextLine();
			pstmt.setString(6, flight_date);
			
			
		
			k=pstmt.executeUpdate();			
		return k;
	}catch (Exception e) {
		System.out.println(e.getMessage());
	}
		return k;
}
}