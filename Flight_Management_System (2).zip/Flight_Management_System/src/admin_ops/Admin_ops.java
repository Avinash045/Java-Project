package admin_ops;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import db_config.Databaseconfig;

public class Admin_ops {
	private int fligtBook=0;
	public int bookflight() {
		try {
			Connection con =DriverManager.getConnection(Databaseconfig.URL,Databaseconfig.USERNAME,Databaseconfig.PASSWORD);
			Scanner sc=new Scanner(System.in);
			PreparedStatement pstmt = con.prepareStatement("insert into flight_info values(?,?,?,?,?)");
			System.out.print("Enter Flight Id: ");
			int id=sc.nextInt();
			pstmt.setInt(1, id);
			System.out.println("Enter Name of Flight: ");
			sc.nextLine();
			String name =sc.nextLine();
			pstmt.setString(2, name);
			System.out.println("Enter your Departure  Point: ");
			String des=sc.nextLine();
			pstmt.setString(3, des);
			System.out.println("Enter your Arrival Point :");
			String board=sc.nextLine();
			pstmt.setString(4, board);
			System.out.println("Enter the Ticket Price: ");
			String price= sc.nextLine();
			pstmt.setString(5, price);
			
			fligtBook=pstmt.executeUpdate();
			System.out.println(fligtBook);
			return fligtBook;
		}catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return 0;
	}
	
	public int deleteFlight() {
		 Connection con = null;
	        PreparedStatement deleteDetailsStmt = null;
	        PreparedStatement deleteFlightStmt = null;
	        Scanner sc = new Scanner(System.in);

	        try {
	            con = DriverManager.getConnection(Databaseconfig.URL, Databaseconfig.USERNAME, Databaseconfig.PASSWORD);
	            con.setAutoCommit(false); // Start transaction

	            System.out.print("Enter the Flight Id you want to delete: ");
	            int flight_id = sc.nextInt();

	            // Step 1: Delete related rows from t_details
	            String deleteDetailsSql = "DELETE FROM t_details WHERE Flight_id = ?";
	            deleteDetailsStmt = con.prepareStatement(deleteDetailsSql);
	            deleteDetailsStmt.setInt(1, flight_id);
	            deleteDetailsStmt.executeUpdate();

	            // Step 2: Delete from flight_info
	            String deleteFlightSql = "DELETE FROM flight_info WHERE Flight_id = ?";
	            deleteFlightStmt = con.prepareStatement(deleteFlightSql);
	            deleteFlightStmt.setInt(1, flight_id);
	            int rowsAffected = deleteFlightStmt.executeUpdate();

	            con.commit(); // Commit transaction

	            return rowsAffected;
	        } catch (Exception e) {
	            if (con != null) {
	                try {
	                    con.rollback(); // Rollback transaction in case of error
	                } catch (SQLException ex) {
	                    ex.printStackTrace();
	                }
	            }
	            System.out.println(e.getMessage());
	            e.printStackTrace();
	        } finally {
	            // Close resources
	            if (deleteDetailsStmt != null) {
	                try {
	                    deleteDetailsStmt.close();
	                } catch (SQLException e) {
	                    e.printStackTrace();
	                }
	            }
	            if (deleteFlightStmt != null) {
	                try {
	                    deleteFlightStmt.close();
	                } catch (SQLException e) {
	                    e.printStackTrace();
	                }
	            }
	            if (con != null) {
	                try {
	                    con.close();
	                } catch (SQLException e) {
	                    e.printStackTrace();
	                }
	            }
	        }
	        return 0;
	}
	
	public int deleteUser() {
        try {
        	Connection con =DriverManager.getConnection(Databaseconfig.URL,Databaseconfig.USERNAME,Databaseconfig.PASSWORD);
            Scanner sc = new Scanner(System.in);

               // Start transaction
               con.setAutoCommit(false);

               // Prepare SQL statements for deleting related records and the user
               PreparedStatement deleteDetails = con.prepareStatement("DELETE FROM t_details WHERE user_id = ?");
               PreparedStatement deleteUser = con.prepareStatement("DELETE FROM user WHERE u_id = ?");

               // Prompt the user to enter the ID of the user to delete
               System.out.print("Enter the user ID you want to delete: ");
               int userId = sc.nextInt();

               // Set the user ID parameter in the SQL statements
               deleteDetails.setInt(1, userId);
               deleteUser.setInt(1, userId);


               // Execute the deletion of the user
               int userDeleted = deleteUser.executeUpdate();
               System.out.println("User record deleted: " + userDeleted);

               // Commit transaction
               con.commit();

           } catch (SQLException e) {
               // Print the SQL exception message and roll back the transaction if there's an error
               System.out.println("An error occurred: " + e.getMessage());
               e.printStackTrace();
               }
        	try {
        		Connection con = null;
				if (con != null) {
                con.rollback();
        		}
        	} catch (SQLException rollbackEx) {
        		rollbackEx.printStackTrace();
        	}
   
		return 0;
	}
}
	
